Sparebeatter V1

本拡張機能はChrome系ブラウザのみに対応しています。動作確認はChromeのみです。

使い方
1.zipファイルを展開します。
2.Chromeの拡張機能のページ(chrome://extensions/)にアクセスします。
3.右上のデベロッパーモードをオンにします。
4.「パッケージ化されていない拡張機能を読み込む」を押します。
5.zipを展開したフォルダ(Sparebeatter Vx.x.xみたいなフォルダ)を選択してOKします。
6.Sparebeatのリザルト画面で右上の拡張機能のところからSparebeatterを押して「Tweetする」を押します。
7.リザルト画像がコピーされた状態でTwitterが開くので、貼り付けます。
8.お好みで文章を編集して投稿！


バグ報告やお問い合わせはTwitter(https://twitter.com/tomo_x_79)、Github(https://github.com/tomo-x7/Sparebeatter)、Discordの非公式Sparebeat交流鯖まで